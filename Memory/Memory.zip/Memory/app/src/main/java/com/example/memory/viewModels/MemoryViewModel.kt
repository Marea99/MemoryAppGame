package com.example.memory.viewModels

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.memory.models.MemoryDificulty
import com.example.memory.models.MemoryStetings

class MemoryViewModel: ViewModel() {
    val dificulies = MemoryDificulty.entries.map { it.toString() }.toList()
    var isMenuDropdownExpanded = MutableLiveData(false)
    var setings by mutableStateOf(MemoryStetings())
        private set

    fun clickDropdown(isExpanded: Boolean) {
        isMenuDropdownExpanded.value = isExpanded
    }

    fun isDificultySet(dificulty: String): Boolean {
        Log.i("ACT", (dificulty == setings.dificulty.toString()).toString())
        return dificulty == setings.dificulty.toString()
    }

    fun setDificulty(dificulty: String) {
        MemoryDificulty.entries.forEach { dif ->
            if (dificulty == dif.toString())
                setings.dificulty = dif
        }
        Log.i("ACT", setings.dificulty.toString())
    }
}