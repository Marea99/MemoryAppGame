package com.example.memory.models

enum class MemoryDificulty {
    Facil,
    Media,
    Dificil
}