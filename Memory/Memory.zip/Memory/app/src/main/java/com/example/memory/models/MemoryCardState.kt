package com.example.memory.models

enum class MemoryCardState {
    AMAGADA,
    VISIBLE,
    EMPARELLADA
}