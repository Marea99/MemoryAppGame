package com.example.memory.models

data class MemoryStetings(
    var dificulty: MemoryDificulty = MemoryDificulty.Media,
    var movimientos: Int = 0,
    var points: Int = 10,
    var aciertos: Int = 0,
    var fallos: Int = 0
)
