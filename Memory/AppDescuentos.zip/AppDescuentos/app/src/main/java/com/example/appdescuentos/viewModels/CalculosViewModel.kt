package com.example.appdescuentos.viewModels

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.appdescuentos.model.CalculosState

class CalculosViewModel: ViewModel() {
    var state by mutableStateOf(CalculosState())
        private set

    fun calcular() {
        val precio = state.precio
        val descuento = state.descuento

        state = if (precio != "" && descuento != "") {
            state.copy(
                precioDescuento = calcularPrecio(precio.toDouble(), descuento.toDouble()),
                totalDescuento = calcularDescuento(precio.toDouble(), descuento.toDouble())
            )
        } else {
            state.copy(mostrarAlerta = true)
        }
    }

    private fun calcularPrecio(precio: Double, descuento: Double): Double {
        val res = precio - calcularDescuento(precio, descuento)
        return kotlin.math.round(res * 100) / 100.0
    }

    private fun calcularDescuento(precio: Double, descuento: Double): Double {
        val res = precio - (1 - descuento / 100)
        return kotlin.math.round(res * 100) / 100.0
    }

    fun cancelAlert() {
        state = state.copy(
            mostrarAlerta = false
        )
    }
}