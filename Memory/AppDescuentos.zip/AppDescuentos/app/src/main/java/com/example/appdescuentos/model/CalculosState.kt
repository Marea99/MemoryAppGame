package com.example.appdescuentos.model

data class CalculosState(
    val precio: String = "",
    val descuento: String = "",
    val precioDescuento: Double = 0.0,
    val totalDescuento: Double = 0.0,
    val mostrarAlerta: Boolean = false
)
