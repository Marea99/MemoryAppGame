package com.example.appdescuentos.views

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.appdescuentos.components.Alert
import com.example.appdescuentos.components.MainButton
import com.example.appdescuentos.components.MainTextField
import com.example.appdescuentos.components.SpaceHeight
import com.example.appdescuentos.components.TwoCards
import com.example.appdescuentos.viewModels.CalculosViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculosView(viewModel: CalculosViewModel) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(text = "App", color = MaterialTheme.colorScheme.onPrimary) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            )
        }
    ) {
        ContentHomeView(it, viewModel)
    }
}

@Composable
fun ContentHomeView(paddingValues: PaddingValues, viewModel: CalculosViewModel) {
    Column(
        modifier = Modifier
            .padding(paddingValues)
            .padding(8.dp)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        TwoCards(
            title1 = "Precio descuento: ",
            number1 = viewModel.state.precioDescuento,
            title2 = "Descuento total: ",
            number2 = viewModel.state.totalDescuento)

        SpaceHeight(16.dp)

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            MainTextField(valor = "0", label = "Precio:") {

            }

            MainTextField(valor = "0", label = "Descuento:") {

            }
        }

        SpaceHeight(16.dp)

        MainButton(text = "Calcula") {
            viewModel.calcular()
        }

        if (viewModel.state.mostrarAlerta) {
            Alert(
                title = "Alerta!",
                message = "Escribe precio y/o descuento",
                confirmText = "Accept",
                onConfirmClick = { viewModel.cancelAlert() },
                onDismissClick = { /*TODO*/ }
            )
        }
    }
}


